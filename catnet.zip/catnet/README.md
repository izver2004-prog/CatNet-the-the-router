# CatNet - VPN router for Windows (v1.1)
Клиент подписок vless / vmess / trojan / shadowsocks / hysteria2 на ядре sing-box (TUN или системный прокси).

## Сборка exe
1. Положи в корень репозитория этот zip (catnet.zip) и файл `.github/workflows/build.yml`.
2. Push -> Actions -> "Build CatNet" -> CatNet.exe в Artifacts.

## Запуск
CatNet.exe просит права администратора (нужны для TUN). Нужен Edge WebView2 (есть в Windows 10/11).
