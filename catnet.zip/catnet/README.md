# CatNet - VPN router for Windows (v1.2)
Клиент подписок vless / vmess / trojan / shadowsocks / hysteria2 на ядре sing-box (TUN или системный прокси).

## Сборка
1. В корень репозитория: этот zip (catnet.zip) и `.github/workflows/build.yml`.
2. Push -> Actions -> "Build CatNet" -> Artifacts:
   - CatNet-folder (рекомендуется: меньше срабатываний Defender) - распакуй папку целиком, запускай CatNet.exe внутри;
   - CatNet-single-exe - один файл, но антивирусы реагируют чаще.
3. Для подписи кода добавь секреты репозитория PFX_BASE64 и PFX_PASSWORD - workflow подпишет exe сам.

## Если Defender всё же ругается
Это ложное срабатывание (неподписанная программа, меняющая прокси и запрашивающая права администратора).
Отправь файл на https://www.microsoft.com/wdsi/filesubmission как "Incorrectly detected as malware".

## Журнал
Настройки -> О программе -> "Журнал ядра" (файл %APPDATA%\CatNet\core.log).
