# CatNet - VPN router for Windows
Клиент для подписок vless / vmess / trojan / shadowsocks / hysteria2 на ядре sing-box (TUN или системный прокси).

## Сборка exe
1. Создай репозиторий на GitHub.
2. Положи в корень репозитория этот zip (catnet.zip) и файл `.github/workflows/build.yml`.
3. Push -> вкладка Actions -> "Build CatNet" -> готовый CatNet.exe в Artifacts.
Workflow сам распакует zip, скачает sing-box и wintun и соберёт один exe.

## Запуск
CatNet.exe просит права администратора (нужны для TUN). Нужен Edge WebView2 (есть в Windows 10/11).
Подписки -> вставь ссылку -> Импортировать -> Серверы -> выбери -> Главная -> кнопка питания.
