# CatNet - VPN router for Windows (v1.3)
Клиент подписок на ядре sing-box (+ Xray для XHTTP/mKCP).
Протоколы: VLESS (Reality, WS, gRPC, HTTPUpgrade, XHTTP), VMess, Trojan, Shadowsocks, Hysteria / Hysteria2,
TUIC, AnyTLS, WireGuard, SOCKS. Подписки: ссылки, base64, Clash YAML, sing-box JSON.

## Сборка
1. В корень репозитория: этот zip (catnet.zip) и `.github/workflows/build.yml`.
2. Push -> Actions -> "Build CatNet" -> Artifacts:
   - CatNet-folder (рекомендуется, меньше срабатываний Defender): распакуй папку целиком, запускай CatNet.exe;
   - CatNet-single-exe: один файл.
3. Подпись кода: секреты репозитория PFX_BASE64 и PFX_PASSWORD.

## Фон / трей
Закрытие окна сворачивает CatNet в трей, VPN продолжает работать (Настройки -> Основные).
Выход: правый клик по иконке в трее -> Выход.

## Журнал
О программе -> "Журнал ядра" (%APPDATA%\CatNet\core.log).
