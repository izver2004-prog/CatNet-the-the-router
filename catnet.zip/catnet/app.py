"""CatNet - VPN router for Windows. Backend: sing-box core + pywebview UI."""
import atexit, base64, collections, concurrent.futures, ctypes, hashlib, json, os
import re, socket, subprocess, sys, threading, time, urllib.request
from urllib.parse import urlsplit, parse_qs, unquote

FROZEN = getattr(sys, "frozen", False)
BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
APPDIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "CatNet")
DATA_FILE = os.path.join(APPDIR, "data.json")
RUN_CFG = os.path.join(APPDIR, "run.json")
CORE = os.path.join(BASE, "sing-box.exe")
API_PORT = 9099
NOWIN = 0x08000000 if os.name == "nt" else 0
VERSION = "1.0.0"

DEFAULTS = dict(theme="light", accent="#FFD873", font=100, lang="ru", autostart=False,
                autoconnect=False, best_server=True, mode="auto", dns="1.1.1.1", ipv6=False,
                auto_route=True, strict_route=True, block_quic=True, routing="global",
                custom_direct="", custom_proxy="", fp="auto", fragment=False, mux=False, port=2080)
CONFIG_KEYS = {"mode", "dns", "ipv6", "auto_route", "strict_route", "block_quic", "routing",
               "custom_direct", "custom_proxy", "fp", "fragment", "mux", "port"}

# ---------------------------------------------------------------- parsing
def b64d(s):
    s = s.strip().replace("-", "+").replace("_", "/")
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s).decode("utf-8", "ignore")


def build_tls(p, host, default_tls=False):
    q = lambda k, d="": (p.get(k) or [d])[0]
    sec = q("security") or ("tls" if default_tls else "")
    if sec not in ("tls", "reality"):
        return None
    tls = {"enabled": True, "server_name": q("sni") or q("peer") or host}
    if q("allowInsecure") in ("1", "true") or q("insecure") in ("1", "true"):
        tls["insecure"] = True
    if q("alpn"):
        tls["alpn"] = q("alpn").split(",")
    fp = q("fp")
    if fp or sec == "reality":
        tls["utls"] = {"enabled": True, "fingerprint": fp or "chrome"}
    if sec == "reality":
        tls["reality"] = {"enabled": True, "public_key": q("pbk"), "short_id": q("sid")}
    return tls


def build_transport(p, host):
    q = lambda k, d="": (p.get(k) or [d])[0]
    t, h = q("type", "tcp"), q("host")
    if t == "ws":
        tr = {"type": "ws", "path": q("path", "/") or "/"}
        if h or host:
            tr["headers"] = {"Host": h or host}
        return tr
    if t == "grpc":
        return {"type": "grpc", "service_name": q("serviceName")}
    if t in ("http", "h2"):
        return {"type": "http", "host": [h or host], "path": q("path", "/") or "/"}
    if t == "httpupgrade":
        return {"type": "httpupgrade", "host": h or host, "path": q("path", "/") or "/"}
    return None


def finish(ob, p, host, default_tls=False):
    tls = build_tls(p, host, default_tls)
    if tls:
        ob["tls"] = tls
    tr = build_transport(p, host)
    if tr:
        ob["transport"] = tr
    return ob


def parse_link(link):
    link = link.strip()
    try:
        if link.startswith("vmess://"):
            j = json.loads(b64d(link[8:]))
            p = {"type": [j.get("net", "tcp")], "host": [j.get("host", "")], "path": [j.get("path", "")],
                 "sni": [j.get("sni", "")], "fp": [j.get("fp", "")], "alpn": [j.get("alpn", "")],
                 "serviceName": [j.get("path", "")], "security": ["tls" if j.get("tls") == "tls" else ""]}
            ob = {"type": "vmess", "tag": "proxy", "server": j["add"], "server_port": int(j["port"]),
                  "uuid": j["id"], "alter_id": int(j.get("aid", 0) or 0), "security": j.get("scy", "auto") or "auto"}
            return j.get("ps", j["add"]), finish(ob, p, j["add"])
        if link.startswith("ss://"):
            s, name = link[5:], ""
            if "#" in s:
                s, name = s.split("#", 1)
                name = unquote(name)
            s = s.split("?")[0]
            if "@" in s:
                ui, hp = s.rsplit("@", 1)
                if ":" not in ui:
                    ui = b64d(ui)
            else:
                ui, hp = b64d(s).rsplit("@", 1)
            method, pw = ui.split(":", 1)
            host, port = hp.rsplit(":", 1)
            return name or host, {"type": "shadowsocks", "tag": "proxy", "server": host.strip("[]"),
                                  "server_port": int(port), "method": method, "password": pw}
        if link.startswith(("hysteria2://", "hy2://")):
            u = urlsplit(link); p = parse_qs(u.query)
            ob = {"type": "hysteria2", "tag": "proxy", "server": u.hostname, "server_port": u.port or 443,
                  "password": unquote(u.username or ""),
                  "tls": {"enabled": True, "server_name": (p.get("sni") or [u.hostname])[0],
                          "insecure": (p.get("insecure") or ["0"])[0] in ("1", "true")}}
            if (p.get("obfs") or [""])[0]:
                ob["obfs"] = {"type": p["obfs"][0], "password": (p.get("obfs-password") or [""])[0]}
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith(("vless://", "trojan://")):
            u = urlsplit(link); p = parse_qs(u.query)
            name = unquote(u.fragment) or u.hostname
            if link.startswith("vless://"):
                ob = {"type": "vless", "tag": "proxy", "server": u.hostname, "server_port": u.port,
                      "uuid": unquote(u.username), "packet_encoding": "xudp"}
                if (p.get("flow") or [""])[0]:
                    ob["flow"] = p["flow"][0]
                return name, finish(ob, p, u.hostname)
            ob = {"type": "trojan", "tag": "proxy", "server": u.hostname, "server_port": u.port,
                  "password": unquote(u.username)}
            return name, finish(ob, p, u.hostname, True)
    except Exception:
        return None
    return None


def from_clash(doc):
    out = []
    for px in doc.get("proxies", []) or []:
        try:
            t, name, host, port = px.get("type"), px.get("name", ""), px["server"], int(px["port"])
            net = px.get("network", "tcp")
            ws, gr = px.get("ws-opts") or {}, px.get("grpc-opts") or {}
            ro = px.get("reality-opts") or {}
            p = {"type": [net], "path": [ws.get("path", "/")], "host": [(ws.get("headers") or {}).get("Host", "")],
                 "serviceName": [gr.get("grpc-service-name", "")],
                 "sni": [px.get("servername") or px.get("sni") or ""], "fp": [px.get("client-fingerprint", "")],
                 "pbk": [ro.get("public-key", "")], "sid": [ro.get("short-id", "")],
                 "security": ["reality" if ro else ("tls" if px.get("tls") else "")]}
            if t == "vless":
                ob = {"type": "vless", "tag": "proxy", "server": host, "server_port": port, "uuid": px["uuid"],
                      "packet_encoding": "xudp"}
                if px.get("flow"):
                    ob["flow"] = px["flow"]
            elif t == "vmess":
                ob = {"type": "vmess", "tag": "proxy", "server": host, "server_port": port, "uuid": px["uuid"],
                      "alter_id": int(px.get("alterId", 0)), "security": px.get("cipher", "auto")}
            elif t == "trojan":
                ob = {"type": "trojan", "tag": "proxy", "server": host, "server_port": port, "password": px["password"]}
                p["security"] = ["tls"]
            elif t == "ss":
                out.append({"name": name, "outbound": {"type": "shadowsocks", "tag": "proxy", "server": host,
                            "server_port": port, "method": px["cipher"], "password": px["password"]}})
                continue
            else:
                continue
            out.append({"name": name, "outbound": finish(ob, p, host, t == "trojan")})
        except Exception:
            continue
    return out


def parse_any(text):
    text = text.strip()
    if text.startswith("{"):
        try:
            doc = json.loads(text)
            res = []
            for o in doc.get("outbounds", []):
                if o.get("type") in ("vless", "vmess", "trojan", "shadowsocks", "hysteria2", "tuic"):
                    o = dict(o); name = o.get("tag", o.get("server", "server")); o["tag"] = "proxy"
                    res.append({"name": name, "outbound": o})
            return res
        except Exception:
            return []
    if re.search(r"^\s*proxies\s*:", text, re.M):
        try:
            import yaml
            return from_clash(yaml.safe_load(text))
        except Exception:
            return []
    first = text.split("\n")[0] if text else ""
    if "://" not in first:
        try:
            text = b64d(text)
        except Exception:
            pass
    res = []
    for line in text.splitlines():
        r = parse_link(line)
        if r:
            res.append({"name": r[0], "outbound": r[1]})
    return res


COUNTRIES = {
    "NL": ["нидерланд", "netherland", "amsterdam", "голланд"], "DE": ["герман", "germany", "frankfurt", "berlin", "франкфурт"],
    "FR": ["франц", "france", "paris", "париж"], "US": ["сша", "usa", "united states", "america", "new york", "los angeles", "miami"],
    "JP": ["япон", "japan", "tokyo"], "CA": ["канад", "canada", "toronto"], "GB": ["великобритан", "united kingdom", "england", "london", "uk"],
    "RU": ["росси", "russia", "moscow", "москва"], "FI": ["финлянд", "finland", "helsinki"], "SE": ["швеци", "sweden", "stockholm"],
    "PL": ["польш", "poland", "warsaw"], "TR": ["турци", "turkey", "istanbul"], "SG": ["сингапур", "singapore"],
    "HK": ["гонконг", "hong kong"], "KZ": ["казахстан", "kazakhstan"], "UA": ["украин", "ukraine"], "CH": ["швейцар", "switzerland"],
    "AT": ["австри", "austria"], "IT": ["итал", "italy"], "ES": ["испан", "spain"], "LT": ["литв", "lithuania"],
    "LV": ["латв", "latvia"], "EE": ["эстон", "estonia"], "AM": ["армен", "armenia"], "GE": ["грузи", "georgia"],
}


def detect_cc(name):
    flags = [c for c in name if 0x1F1E6 <= ord(c) <= 0x1F1FF]
    if len(flags) >= 2:
        return "".join(chr(ord(c) - 0x1F1E6 + 65) for c in flags[:2])
    n = name.lower()
    for cc, kws in COUNTRIES.items():
        if any(k in n for k in kws) or re.search(r"(?<![a-z])%s(?![a-z])" % cc.lower(), n):
            return cc
    return ""


def clean_name(name):
    return re.sub("[\U0001F1E6-\U0001F1FF]", "", name).strip() or "Server"


def sid_of(name, ob):
    key = "|".join(str(x) for x in (ob.get("type"), ob.get("server"), ob.get("server_port"),
                                    ob.get("uuid") or ob.get("password") or "", name))
    return hashlib.sha1(key.encode()).hexdigest()[:10]


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "v2rayN/6.45"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", "ignore")


# ---------------------------------------------------------------- core config
def domains(text):
    return [d.strip().lower() for d in re.split(r"[\s,;]+", text or "") if d.strip()]


def build_config(ob, S, mode):
    ob = json.loads(json.dumps(ob))
    typ = ob.get("type")
    tls = ob.get("tls")
    if tls and tls.get("enabled"):
        if typ in ("vless", "vmess", "trojan"):
            if S["fp"] != "auto":
                tls["utls"] = {"enabled": True, "fingerprint": S["fp"]}
            elif "utls" not in tls:
                tls["utls"] = {"enabled": True, "fingerprint": "chrome"}
            if S["fragment"] and "reality" not in tls:
                tls["fragment"] = True
    if (S["mux"] and typ in ("vless", "vmess", "trojan", "shadowsocks") and not ob.get("flow")
            and (ob.get("transport") or {}).get("type") != "grpc"):
        ob["multiplex"] = {"enabled": True, "protocol": "h2mux", "max_connections": 4, "padding": True}
    ob["tag"] = "proxy"
    if mode == "tun":
        addr = ["172.19.0.1/30"] + (["fdfe:dcba:9876::1/126"] if S["ipv6"] else [])
        inbound = {"type": "tun", "tag": "tun-in", "address": addr, "auto_route": bool(S["auto_route"]),
                   "strict_route": bool(S["strict_route"]), "stack": "mixed"}
    else:
        inbound = {"type": "mixed", "tag": "in", "listen": "127.0.0.1", "listen_port": int(S["port"])}
    rules = [{"action": "sniff"}, {"protocol": "dns", "action": "hijack-dns"}]
    if S["block_quic"]:
        rules.append({"protocol": "quic", "action": "reject"})
    rules.append({"ip_is_private": True, "outbound": "direct"})
    if domains(S["custom_proxy"]):
        rules.append({"domain_suffix": domains(S["custom_proxy"]), "outbound": "proxy"})
    if domains(S["custom_direct"]):
        rules.append({"domain_suffix": domains(S["custom_direct"]), "outbound": "direct"})
    if S["routing"] == "bypass_ru":
        rules.append({"domain_suffix": ["ru", "su", "xn--p1ai"], "outbound": "direct"})
    return {
        "log": {"level": "info", "timestamp": True},
        "dns": {"servers": [{"type": "https", "tag": "remote", "server": S["dns"], "detour": "proxy"},
                            {"type": "local", "tag": "local"}],
                "final": "remote", "strategy": "prefer_ipv4" if S["ipv6"] else "ipv4_only"},
        "inbounds": [inbound],
        "outbounds": [ob, {"type": "direct", "tag": "direct"}],
        "route": {"auto_detect_interface": True, "final": "proxy", "rules": rules,
                  "default_domain_resolver": {"server": "local"}},
        "experimental": {"clash_api": {"external_controller": f"127.0.0.1:{API_PORT}"}},
    }


# ---------------------------------------------------------------- windows helpers
def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def set_sys_proxy(enable, port=2080):
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                           0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
        if enable:
            winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, f"127.0.0.1:{port}")
            winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, "<local>")
        winreg.CloseKey(k)
        ctypes.windll.wininet.InternetSetOptionW(0, 39, 0, 0)
        ctypes.windll.wininet.InternetSetOptionW(0, 37, 0, 0)
    except Exception:
        pass


def set_autostart(on):
    if not FROZEN or os.name != "nt":
        return
    try:
        if on:
            subprocess.run(["schtasks", "/Create", "/TN", "CatNet", "/TR", f'"{sys.executable}"', "/SC", "ONLOGON",
                            "/RL", "HIGHEST", "/F"], creationflags=NOWIN, capture_output=True)
        else:
            subprocess.run(["schtasks", "/Delete", "/TN", "CatNet", "/F"], creationflags=NOWIN, capture_output=True)
    except Exception:
        pass


def tcp_ping(host, port):
    try:
        t = time.time()
        with socket.create_connection((host, int(port)), timeout=2.5):
            return int((time.time() - t) * 1000)
    except Exception:
        return None


# ---------------------------------------------------------------- API exposed to the UI
class Api:
    def __init__(self):
        os.makedirs(APPDIR, exist_ok=True)
        self._window = None
        self._lock = threading.RLock()
        self._proc = None
        self._mode = None
        self._log = collections.deque(maxlen=300)
        self._hist_d = collections.deque([0] * 60, maxlen=60)
        self._hist_u = collections.deque([0] * 60, maxlen=60)
        self._down = self._up = 0
        self._tot = (0, 0)
        self._since = 0
        self._ip = ""
        self._error = ""
        self._ping = {}
        self._cur = ""
        try:
            self._d = json.load(open(DATA_FILE, encoding="utf-8"))
        except Exception:
            self._d = {}
        for k, v in dict(settings={}, subs=[], fav=[], recent=[], selected="",
                         stats={"sessions": 0, "down": 0, "up": 0}, profile={"name": "CatNet User"}).items():
            self._d.setdefault(k, v)
        for k, v in DEFAULTS.items():
            self._d["settings"].setdefault(k, v)
        atexit.register(self._cleanup)

    # -- storage
    def _save(self):
        with self._lock:
            json.dump(self._d, open(DATA_FILE, "w", encoding="utf-8"), ensure_ascii=False)

    def _servers(self):
        for sub in self._d["subs"]:
            for s in sub["servers"]:
                yield sub, s

    def _find(self, sid):
        for _, s in self._servers():
            if s["id"] == sid:
                return s
        return None

    # -- state
    def get_state(self):
        d = self._d
        servers = [{"id": s["id"], "name": s["name"], "sub": sub["name"], "cc": s["cc"],
                    "ping": self._ping.get(s["id"]), "fav": s["id"] in d["fav"]} for sub, s in self._servers()]
        subs = [{"id": s["id"], "name": s["name"], "url": s["url"], "updated": s["updated"],
                 "count": len(s["servers"])} for s in d["subs"]]
        return {"settings": d["settings"], "subs": subs, "servers": servers, "selected": d["selected"],
                "recent": d["recent"], "stats": d["stats"], "profile": d["profile"], "admin": is_admin(),
                "core": os.path.exists(CORE), "version": VERSION, "frozen": FROZEN}

    # -- subscriptions
    def _make_servers(self, items):
        out, seen = [], set()
        for it in items:
            name = clean_name(it["name"])
            sid = sid_of(name, it["outbound"])
            if sid in seen:
                continue
            seen.add(sid)
            out.append({"id": sid, "name": name, "cc": detect_cc(it["name"]), "outbound": it["outbound"]})
        return out

    def add_subscription(self, url):
        url = (url or "").strip()
        if not url.startswith(("http://", "https://")):
            return {"ok": False, "error": "Введите ссылку подписки (http/https)"}
        try:
            items = parse_any(fetch(url))
        except Exception as e:
            return {"ok": False, "error": f"Не удалось загрузить: {e}"}
        if not items:
            return {"ok": False, "error": "В подписке не найдено серверов"}
        with self._lock:
            sub = next((s for s in self._d["subs"] if s["url"] == url), None)
            if not sub:
                sub = {"id": hashlib.sha1(url.encode()).hexdigest()[:8], "name": urlsplit(url).hostname or "Подписка",
                       "url": url, "updated": 0, "servers": []}
                self._d["subs"].append(sub)
            sub["servers"] = self._make_servers(items)
            sub["updated"] = int(time.time())
        self._save()
        return {"ok": True, "count": len(sub["servers"])}

    def import_text(self, name, text):
        items = parse_any(text or "")
        if not items:
            return {"ok": False, "error": "Не удалось распознать серверы в файле"}
        sid = hashlib.sha1((name + str(time.time())).encode()).hexdigest()[:8]
        with self._lock:
            self._d["subs"].append({"id": sid, "name": name or "Файл", "url": "", "updated": int(time.time()),
                                    "servers": self._make_servers(items)})
        self._save()
        return {"ok": True, "count": len(items)}

    def refresh_subscription(self, sub_id):
        sub = next((s for s in self._d["subs"] if s["id"] == sub_id), None)
        if not sub or not sub["url"]:
            return {"ok": False, "error": "Для файла обновление недоступно"}
        return self.add_subscription(sub["url"])

    def remove_subscription(self, sub_id):
        with self._lock:
            self._d["subs"] = [s for s in self._d["subs"] if s["id"] != sub_id]
        self._save()
        return True

    # -- servers
    def toggle_fav(self, sid):
        fav = self._d["fav"]
        fav.remove(sid) if sid in fav else fav.append(sid)
        self._save()
        return True

    def select_server(self, sid):
        self._d["selected"] = sid
        self._save()
        if self._proc:
            return self.connect()
        return {"ok": True}

    def ping_all(self):
        items = [(s["id"], s["outbound"]) for _, s in self._servers()]
        with concurrent.futures.ThreadPoolExecutor(32) as ex:
            res = list(ex.map(lambda it: (it[0], tcp_ping(it[1]["server"], it[1]["server_port"])), items))
        self._ping = {k: v for k, v in res if v is not None}
        return self._ping

    # -- settings
    def set_setting(self, key, value):
        if key not in DEFAULTS:
            return False
        self._d["settings"][key] = value
        self._save()
        if key == "autostart":
            set_autostart(bool(value))
        if key in CONFIG_KEYS and self._proc:
            self.connect()
        return True

    def reset_settings(self):
        self._d["settings"] = dict(DEFAULTS)
        self._save()
        return self._d["settings"]

    def set_profile_name(self, name):
        self._d["profile"]["name"] = (name or "CatNet User")[:40]
        self._save()
        return True

    # -- connection
    def connect(self):
        with self._lock:
            self._stop()
            S = self._d["settings"]
            if not os.path.exists(CORE):
                return {"ok": False, "error": "Не найден sing-box.exe (ядро). Пересоберите проект."}
            sid = self._d["selected"]
            srv = self._find(sid)
            if not srv:
                if not any(True for _ in self._servers()):
                    return {"ok": False, "error": "Нет серверов. Добавьте подписку."}
                if S["best_server"]:
                    self.ping_all()
                    cand = [s for _, s in self._servers() if s["id"] in self._ping]
                    srv = min(cand, key=lambda s: self._ping[s["id"]]) if cand else next(s for _, s in self._servers())
                else:
                    srv = next(s for _, s in self._servers())
                self._d["selected"] = srv["id"]
            mode = S["mode"]
            if mode == "auto":
                mode = "tun" if is_admin() else "proxy"
            cfg = build_config(srv["outbound"], S, mode)
            json.dump(cfg, open(RUN_CFG, "w"), indent=1)
            self._log.clear()
            try:
                p = subprocess.Popen([CORE, "run", "-c", RUN_CFG], cwd=BASE, stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="ignore",
                                     creationflags=NOWIN)
            except Exception as e:
                return {"ok": False, "error": f"Не удалось запустить ядро: {e}"}
            self._proc, self._mode, self._cur = p, mode, srv["id"]
            threading.Thread(target=self._reader, args=(p,), daemon=True).start()
            for _ in range(25):
                time.sleep(0.1)
                if p.poll() is not None:
                    break
            if p.poll() is not None:
                err = "\n".join(list(self._log)[-6:]) or "Ядро завершилось с ошибкой"
                self._proc = None
                return {"ok": False, "error": err}
            if mode == "proxy":
                set_sys_proxy(True, S["port"])
            self._since = time.time()
            self._down = self._up = 0
            self._tot = (0, 0)
            self._ip = ""
            self._error = ""
            for h in (self._hist_d, self._hist_u):
                h.extend([0] * 60)
            rec = [x for x in self._d["recent"] if x != srv["id"]]
            self._d["recent"] = ([srv["id"]] + rec)[:10]
            self._save()
            threading.Thread(target=self._stats, args=(p,), daemon=True).start()
            threading.Thread(target=self._get_ip, args=(p, mode, S["port"]), daemon=True).start()
            return {"ok": True}

    def _reader(self, p):
        try:
            for line in p.stdout:
                self._log.append(line.rstrip())
        except Exception:
            pass

    def _stats(self, p):
        last = None
        while self._proc is p and p.poll() is None:
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{API_PORT}/connections", timeout=2) as r:
                    j = json.loads(r.read().decode())
                d, u = j.get("downloadTotal", 0), j.get("uploadTotal", 0)
                if last:
                    self._down, self._up = max(0, d - last[0]), max(0, u - last[1])
                last, self._tot = (d, u), (d, u)
            except Exception:
                self._down = self._up = 0
            self._hist_d.append(self._down)
            self._hist_u.append(self._up)
            time.sleep(1)

    def _get_ip(self, p, mode, port):
        time.sleep(2)
        for _ in range(4):
            if self._proc is not p:
                return
            try:
                h = urllib.request.ProxyHandler({"http": f"http://127.0.0.1:{port}", "https": f"http://127.0.0.1:{port}"}
                                                if mode == "proxy" else {})
                op = urllib.request.build_opener(h)
                self._ip = op.open("https://api.ipify.org", timeout=6).read().decode().strip()
                return
            except Exception:
                time.sleep(2)

    def _stop(self):
        p = self._proc
        if p:
            self._proc = None
            d, u = self._tot
            st = self._d["stats"]
            st["sessions"] += 1; st["down"] += d; st["up"] += u
            try:
                p.terminate(); p.wait(5)
            except Exception:
                try: p.kill()
                except Exception: pass
        if self._mode == "proxy":
            set_sys_proxy(False)
        self._mode = None
        self._down = self._up = 0
        self._ip = ""

    def disconnect(self):
        with self._lock:
            self._stop()
            self._save()
        return True

    def _cleanup(self):
        try:
            self._stop()
        except Exception:
            pass

    def get_status(self):
        p = self._proc
        if p and p.poll() is not None:
            self._error = "\n".join(list(self._log)[-4:]) or "Ядро остановлено"
            with self._lock:
                self._stop()
            p = None
        return {"connected": bool(p), "down": self._down, "up": self._up, "hist": list(self._hist_d),
                "ip": self._ip, "since": self._since if p else 0, "server": self._cur if p else "",
                "error": self._error, "log": list(self._log)[-40:]}

    # -- window
    def minimize(self):
        self._window.minimize()

    def maximize(self):
        try:
            if getattr(self, "_max", False):
                self._window.restore()
            else:
                self._window.maximize()
            self._max = not getattr(self, "_max", False)
        except Exception:
            pass

    def close(self):
        self._cleanup()
        self._window.destroy()


def main():
    import webview
    api = Api()
    s = api._d["settings"]
    dark = s["theme"] == "dark"
    win = webview.create_window("CatNet", os.path.join(BASE, "ui", "index.html"), js_api=api,
                                width=1080, height=700, min_size=(940, 620), frameless=True,
                                background_color="#2B2B2D" if dark else "#F5F3EF")
    api._window = win
    webview.start()
    api._cleanup()


if __name__ == "__main__":
    main()
