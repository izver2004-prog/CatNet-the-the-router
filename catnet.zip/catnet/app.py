"""CatNet - VPN router for Windows. Backend: sing-box core + pywebview UI."""
import atexit, base64, collections, concurrent.futures, ctypes, hashlib, json, os
import re, socket, subprocess, sys, threading, time, urllib.request
from urllib.parse import urlsplit, parse_qs, unquote

FROZEN = getattr(sys, "frozen", False)
BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
APPDIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "CatNet")
DATA_FILE = os.path.join(APPDIR, "data.json")
RUN_CFG = os.path.join(APPDIR, "run.json")
CORE = os.path.join(BASE, "sing-box.exe")
XRAY = os.path.join(BASE, "xray.exe")
XRAY_CFG = os.path.join(APPDIR, "xray.json")
API_PORT = 9099
PING_API = 9098
PING_PORT = 9097
PING_CFG = os.path.join(APPDIR, "ping.json")
PING_LOG = os.path.join(APPDIR, "ping.log")
CORE_LOG = os.path.join(APPDIR, "core.log")
NOWIN = 0x08000000 if os.name == "nt" else 0
VERSION = "1.3.0"

DEFAULTS = dict(theme="light", accent="#FFD873", font=100, lang="ru", autostart=False,
                autoconnect=False, best_server=True, mode="auto", dns="1.1.1.1", ipv6=False,
                auto_route=True, strict_route=True, block_quic=True, routing="global",
                custom_direct="", custom_proxy="", fp="auto", fragment=False, mux=False, port=2080,
                ping_method="tcp", ping_url="https://www.gstatic.com/generate_204", failover=True,
                tray=True, tun_stack="mixed", tun_mtu=0, hy_up=0, hy_down=0)
CONFIG_KEYS = {"mode", "dns", "ipv6", "auto_route", "strict_route", "block_quic", "routing",
               "custom_direct", "custom_proxy", "fp", "fragment", "mux", "port", "tun_stack", "tun_mtu", "hy_up", "hy_down"}

# ---------------------------------------------------------------- parsing
UDP_TYPES = {"hysteria", "hysteria2", "tuic", "wireguard"}
JSON_TYPES = ("vless", "vmess", "trojan", "shadowsocks", "hysteria", "hysteria2", "tuic", "anytls", "socks", "http")
SCHEMES = ("vless://", "vmess://", "trojan://", "ss://", "hy2://", "hysteria2://", "hysteria://", "tuic://",
           "anytls://", "socks://", "socks5://", "socks4://", "socks4a://", "wireguard://", "wg://")


class NeedXray(Exception):
    """Link uses a transport/feature sing-box does not implement (XHTTP, mKCP, VLESS encryption)."""


def b64d(s):
    s = s.strip().replace("-", "+").replace("_", "/")
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s).decode("utf-8", "ignore")


def addr_of(ob):
    if ob.get("type") == "wireguard":
        p = (ob.get("peers") or [{}])[0]
        return p.get("address", ""), p.get("port", 0)
    return ob.get("server", ""), ob.get("server_port", 0)


def is_udp(ob):
    return ob.get("type") in UDP_TYPES or bool(ob.get("_udp"))


def _num(x, d=0):
    m = re.search(r"\d+", str(x or ""))
    return int(m.group()) if m else d


def _tlsd(host, sni="", alpn="", insecure=False):
    t = {"enabled": True, "server_name": sni or host}
    if alpn:
        t["alpn"] = [a for a in str(alpn).split(",") if a]
    if insecure:
        t["insecure"] = True
    return t


def build_tls(p, host, default_tls=False):
    q = lambda k, d="": (p.get(k) or [d])[0]
    sec = q("security") or ("tls" if default_tls else "")
    if sec not in ("tls", "reality"):
        return None
    if sec == "reality" and not q("pbk"):
        raise ValueError("reality without public key")
    tls = {"enabled": True, "server_name": q("sni") or q("peer") or host}
    if q("allowInsecure") in ("1", "true") or q("insecure") in ("1", "true"):
        tls["insecure"] = True
    if q("alpn"):
        tls["alpn"] = q("alpn").split(",")
    fp = q("fp")
    if fp or sec == "reality":
        tls["utls"] = {"enabled": True, "fingerprint": fp or "chrome"}
    if sec == "reality":
        tls["reality"] = {"enabled": True, "public_key": q("pbk"), "short_id": q("sid")}
    return tls


def build_transport(p, host):
    q = lambda k, d="": (p.get(k) or [d])[0]
    t, h = q("type", "tcp"), q("host")
    if t in ("xhttp", "splithttp", "kcp", "mkcp"):
        raise NeedXray()
    if t == "quic":
        raise ValueError("quic transport is not supported")
    if t == "ws":
        path = q("path", "/") or "/"
        tr = {"type": "ws"}
        m = re.search(r"[?&]ed=(\d+)", path)
        if m:
            tr["max_early_data"] = int(m.group(1))
            tr["early_data_header_name"] = "Sec-WebSocket-Protocol"
            path = re.sub(r"\?ed=\d+&", "?", path)
            path = re.sub(r"[?&]ed=\d+", "", path) or "/"
        tr["path"] = path
        if h or host:
            tr["headers"] = {"Host": h or host}
        return tr
    if t == "grpc":
        return {"type": "grpc", "service_name": q("serviceName")}
    if t in ("http", "h2"):
        return {"type": "http", "host": [h or host], "path": q("path", "/") or "/"}
    if t == "httpupgrade":
        return {"type": "httpupgrade", "host": h or host, "path": q("path", "/") or "/"}
    return None


def finish(ob, p, host, default_tls=False):
    tls = build_tls(p, host, default_tls)
    if tls:
        ob["tls"] = tls
    tr = build_transport(p, host)
    if tr:
        ob["transport"] = tr
    return ob


# ---- Xray fallback (XHTTP / mKCP / VLESS encryption): Xray runs locally as SOCKS, sing-box chains to it
def xray_stream(p, host):
    q = lambda k, d="": (p.get(k) or [d])[0]
    net = {"": "tcp", "tcp": "tcp", "xhttp": "xhttp", "splithttp": "xhttp", "kcp": "kcp", "mkcp": "kcp",
           "ws": "ws", "grpc": "grpc", "httpupgrade": "httpupgrade", "h2": "http", "http": "http"}.get(q("type", "tcp"), "tcp")
    ss = {"network": net}
    sec = q("security")
    if sec == "tls":
        ss["security"] = "tls"
        ss["tlsSettings"] = {"serverName": q("sni") or host, "fingerprint": q("fp") or "chrome",
                             "allowInsecure": q("allowInsecure") in ("1", "true")}
        if q("alpn"):
            ss["tlsSettings"]["alpn"] = q("alpn").split(",")
    elif sec == "reality":
        ss["security"] = "reality"
        ss["realitySettings"] = {"serverName": q("sni") or host, "fingerprint": q("fp") or "chrome",
                                 "publicKey": q("pbk"), "shortId": q("sid"), "spiderX": q("spx")}
    path, hh = q("path", "/") or "/", q("host")
    if net == "xhttp":
        xs = {"path": path, "mode": q("mode", "auto")}
        if hh:
            xs["host"] = hh
        if q("extra"):
            try: xs["extra"] = json.loads(q("extra"))
            except Exception: pass
        ss["xhttpSettings"] = xs
    elif net == "kcp":
        ks = {"header": {"type": q("headerType", "none")}}
        if q("seed"):
            ks["seed"] = q("seed")
        ss["kcpSettings"] = ks
    elif net == "ws":
        ss["wsSettings"] = {"path": path, "headers": {"Host": hh or host}}
    elif net == "grpc":
        ss["grpcSettings"] = {"serviceName": q("serviceName"), "multiMode": q("mode") == "multi"}
    elif net == "httpupgrade":
        ss["httpupgradeSettings"] = {"path": path, "host": hh or host}
    elif net == "http":
        ss["httpSettings"] = {"path": path, "host": [hh or host]}
    return ss


def xray_from_link(link):
    if link.startswith("vmess://"):
        j = json.loads(b64d(link[8:]))
        host, port, name = j["add"], int(j["port"]), j.get("ps", j["add"])
        p = {"type": [j.get("net", "tcp")], "host": [j.get("host", "")], "path": [j.get("path", "")],
             "sni": [j.get("sni", "")], "fp": [j.get("fp", "")], "alpn": [j.get("alpn", "")],
             "serviceName": [j.get("path", "")], "security": ["tls" if j.get("tls") == "tls" else ""],
             "headerType": [j.get("type", "none")], "seed": [j.get("path", "")]}
        proto = "vmess"
        settings = {"vnext": [{"address": host, "port": port, "users": [
            {"id": j["id"], "alterId": int(j.get("aid", 0) or 0), "security": j.get("scy", "auto") or "auto"}]}]}
    else:
        u = urlsplit(link)
        p = parse_qs(u.query)
        host, port, name = u.hostname, u.port, unquote(u.fragment) or u.hostname
        if link.startswith("vless://"):
            proto = "vless"
            user = {"id": unquote(u.username), "encryption": (p.get("encryption") or ["none"])[0] or "none"}
            if (p.get("flow") or [""])[0]:
                user["flow"] = p["flow"][0]
            settings = {"vnext": [{"address": host, "port": port, "users": [user]}]}
        else:
            proto = "trojan"
            settings = {"servers": [{"address": host, "port": port, "password": unquote(u.username)}]}
            if not (p.get("security") or [""])[0]:
                p["security"] = ["tls"]
    ss = xray_stream(p, host)
    ob = {"type": "xray", "tag": "proxy", "server": host, "server_port": port,
          "_xray": {"protocol": proto, "tag": "proxy", "settings": settings, "streamSettings": ss},
          "_udp": ss["network"] == "kcp"}
    return name, ob


def make_xray_config(xo, port):
    return {"log": {"loglevel": "warning"},
            "inbounds": [{"listen": "127.0.0.1", "port": port, "protocol": "socks",
                          "settings": {"udp": True, "auth": "noauth"}}],
            "outbounds": [xo]}


def parse_link(link):
    link = link.strip()
    try:
        if link.startswith("vmess://"):
            j = json.loads(b64d(link[8:]))
            p = {"type": [j.get("net", "tcp")], "host": [j.get("host", "")], "path": [j.get("path", "")],
                 "sni": [j.get("sni", "")], "fp": [j.get("fp", "")], "alpn": [j.get("alpn", "")],
                 "serviceName": [j.get("path", "")], "security": ["tls" if j.get("tls") == "tls" else ""]}
            ob = {"type": "vmess", "tag": "proxy", "server": j["add"], "server_port": int(j["port"]),
                  "uuid": j["id"], "alter_id": int(j.get("aid", 0) or 0), "security": j.get("scy", "auto") or "auto"}
            return j.get("ps", j["add"]), finish(ob, p, j["add"])
        if link.startswith("ss://"):
            if "plugin=" in link:
                raise ValueError("shadowsocks plugins need external binaries")
            s, name = link[5:], ""
            if "#" in s:
                s, name = s.split("#", 1)
                name = unquote(name)
            s = s.split("?")[0]
            if "@" in s:
                ui, hp = s.rsplit("@", 1)
                if ":" not in ui:
                    ui = b64d(ui)
            else:
                ui, hp = b64d(s).rsplit("@", 1)
            method, pw = ui.split(":", 1)
            host, port = hp.rsplit(":", 1)
            return name or host, {"type": "shadowsocks", "tag": "proxy", "server": host.strip("[]"),
                                  "server_port": int(port), "method": method, "password": pw}
        if link.startswith(("hysteria2://", "hy2://")):
            u = urlsplit(link); p = parse_qs(u.query)
            q = lambda k, d="": (p.get(k) or [d])[0]
            ob = {"type": "hysteria2", "tag": "proxy", "server": u.hostname, "server_port": u.port or 443,
                  "password": unquote(u.username or "") + (":" + unquote(u.password) if u.password else ""),
                  "tls": _tlsd(u.hostname, q("sni"), q("alpn"), q("insecure") in ("1", "true"))}
            if q("obfs"):
                ob["obfs"] = {"type": q("obfs"), "password": q("obfs-password")}
            mp = q("mport") or q("ports")
            if mp:
                ob["server_ports"] = [x.strip().replace("-", ":") for x in mp.split(",") if x.strip()]
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith("hysteria://"):
            u = urlsplit(link); p = parse_qs(u.query)
            q = lambda k, d="": (p.get(k) or [d])[0]
            if q("protocol", "udp") not in ("udp", ""):
                raise ValueError("hysteria faketcp/wechat-video not supported")
            ob = {"type": "hysteria", "tag": "proxy", "server": u.hostname, "server_port": u.port or 443,
                  "up_mbps": _num(q("upmbps") or q("up"), 100), "down_mbps": _num(q("downmbps") or q("down"), 100),
                  "tls": _tlsd(u.hostname, q("peer") or q("sni"), q("alpn"), q("insecure") in ("1", "true"))}
            if q("auth"):
                ob["auth_str"] = q("auth")
            if q("obfs"):
                ob["obfs"] = q("obfsParam") or q("obfs")
            mp = q("mport")
            if mp:
                ob["server_ports"] = [x.strip().replace("-", ":") for x in mp.split(",") if x.strip()]
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith("tuic://"):
            u = urlsplit(link); p = parse_qs(u.query)
            q = lambda k, d="": (p.get(k) or [d])[0]
            ob = {"type": "tuic", "tag": "proxy", "server": u.hostname, "server_port": u.port or 443,
                  "uuid": unquote(u.username or ""), "password": unquote(u.password or ""),
                  "congestion_control": q("congestion_control") or q("congestion-controller") or "bbr",
                  "udp_relay_mode": q("udp_relay_mode") or q("udp-relay-mode") or "native",
                  "tls": _tlsd(u.hostname, q("sni"), q("alpn", "h3"), q("allow_insecure") in ("1", "true") or q("insecure") in ("1", "true"))}
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith("anytls://"):
            u = urlsplit(link); p = parse_qs(u.query)
            q = lambda k, d="": (p.get(k) or [d])[0]
            ob = {"type": "anytls", "tag": "proxy", "server": u.hostname, "server_port": u.port or 443,
                  "password": unquote(u.username or ""),
                  "tls": _tlsd(u.hostname, q("sni") or q("peer"), q("alpn"), q("insecure") in ("1", "true") or q("allowInsecure") in ("1", "true"))}
            if q("fp"):
                ob["tls"]["utls"] = {"enabled": True, "fingerprint": q("fp")}
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith(("socks://", "socks5://", "socks4://", "socks4a://")):
            u = urlsplit(link)
            user, pw = unquote(u.username or ""), unquote(u.password or "")
            if user and not pw:
                try:
                    d = b64d(user)
                    if ":" in d:
                        user, pw = d.split(":", 1)
                except Exception:
                    pass
            ob = {"type": "socks", "tag": "proxy", "server": u.hostname, "server_port": u.port or 1080,
                  "version": "4" if link.startswith("socks4") else "5"}
            if user:
                ob["username"], ob["password"] = user, pw
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith(("wireguard://", "wg://")):
            u = urlsplit(link); p = parse_qs(u.query)
            q = lambda k, d="": (p.get(k) or [d])[0]
            addrs = [a.strip() if "/" in a else a.strip() + ("/128" if ":" in a else "/32")
                     for a in (q("address") or q("ip") or "10.0.0.2/32").split(",") if a.strip()]
            peer = {"address": u.hostname, "port": u.port or 51820,
                    "public_key": q("publickey") or q("public_key") or q("peer_public_key"),
                    "allowed_ips": ["0.0.0.0/0", "::/0"]}
            if q("presharedkey") or q("psk"):
                peer["pre_shared_key"] = q("presharedkey") or q("psk")
            if q("reserved"):
                peer["reserved"] = [int(x) for x in q("reserved").split(",") if x.strip().isdigit()]
            ob = {"type": "wireguard", "tag": "proxy", "address": addrs, "private_key": unquote(u.username or ""),
                  "mtu": _num(q("mtu"), 1408), "peers": [peer]}
            return unquote(u.fragment) or u.hostname, ob
        if link.startswith(("vless://", "trojan://")):
            u = urlsplit(link); p = parse_qs(u.query)
            name = unquote(u.fragment) or u.hostname
            if link.startswith("vless://"):
                if (p.get("encryption") or ["none"])[0] not in ("none", ""):
                    raise NeedXray()
                ob = {"type": "vless", "tag": "proxy", "server": u.hostname, "server_port": u.port,
                      "uuid": unquote(u.username), "packet_encoding": "xudp"}
                if (p.get("flow") or [""])[0]:
                    ob["flow"] = p["flow"][0]
                return name, finish(ob, p, u.hostname)
            ob = {"type": "trojan", "tag": "proxy", "server": u.hostname, "server_port": u.port,
                  "password": unquote(u.username)}
            return name, finish(ob, p, u.hostname, True)
    except NeedXray:
        try:
            return xray_from_link(link)
        except Exception:
            return None
    except Exception:
        return None
    return None


def _clash_tls(px, host):
    alpn = px.get("alpn")
    alpn = ",".join(alpn) if isinstance(alpn, list) else (alpn or "")
    return _tlsd(host, px.get("sni") or px.get("servername") or "", alpn, bool(px.get("skip-cert-verify")))


def from_clash(doc):
    out = []
    for px in doc.get("proxies", []) or []:
        try:
            t, name, host, port = (px.get("type") or "").lower(), px.get("name", ""), px["server"], int(px["port"])
            net = px.get("network", "tcp")
            ws, gr, ro = px.get("ws-opts") or {}, px.get("grpc-opts") or {}, px.get("reality-opts") or {}
            h2, hu = px.get("h2-opts") or {}, px.get("http-upgrade-opts") or {}
            alpn = px.get("alpn")
            alpn = ",".join(alpn) if isinstance(alpn, list) else (alpn or "")
            p = {"type": [net], "path": [ws.get("path") or h2.get("path") or hu.get("path") or "/"],
                 "host": [(ws.get("headers") or {}).get("Host", "") or hu.get("host", "")],
                 "serviceName": [gr.get("grpc-service-name", "")],
                 "sni": [px.get("servername") or px.get("sni") or ""], "fp": [px.get("client-fingerprint", "")],
                 "alpn": [alpn], "allowInsecure": ["1" if px.get("skip-cert-verify") else ""],
                 "pbk": [ro.get("public-key", "")], "sid": [ro.get("short-id", "")],
                 "security": ["reality" if ro else ("tls" if px.get("tls") else "")]}
            if t == "vless":
                ob = {"type": "vless", "tag": "proxy", "server": host, "server_port": port, "uuid": px["uuid"],
                      "packet_encoding": "xudp"}
                if px.get("flow"):
                    ob["flow"] = px["flow"]
            elif t == "vmess":
                ob = {"type": "vmess", "tag": "proxy", "server": host, "server_port": port, "uuid": px["uuid"],
                      "alter_id": int(px.get("alterId", 0)), "security": px.get("cipher", "auto")}
            elif t == "trojan":
                ob = {"type": "trojan", "tag": "proxy", "server": host, "server_port": port, "password": px["password"]}
                p["security"] = ["tls"]
            elif t == "ss":
                if px.get("plugin"):
                    continue
                out.append({"name": name, "outbound": {"type": "shadowsocks", "tag": "proxy", "server": host,
                            "server_port": port, "method": px["cipher"], "password": px["password"]}})
                continue
            elif t == "hysteria2":
                ob = {"type": "hysteria2", "tag": "proxy", "server": host, "server_port": port,
                      "password": str(px["password"]), "tls": _clash_tls(px, host)}
                if px.get("obfs"):
                    ob["obfs"] = {"type": px["obfs"], "password": px.get("obfs-password", "")}
                if px.get("ports"):
                    ob["server_ports"] = [x.strip().replace("-", ":") for x in str(px["ports"]).split(",")]
                out.append({"name": name, "outbound": ob}); continue
            elif t == "hysteria":
                ob = {"type": "hysteria", "tag": "proxy", "server": host, "server_port": port,
                      "up_mbps": _num(px.get("up"), 100), "down_mbps": _num(px.get("down"), 100),
                      "tls": _clash_tls(px, host)}
                if px.get("auth-str") or px.get("auth"):
                    ob["auth_str"] = px.get("auth-str") or px.get("auth")
                if px.get("obfs"):
                    ob["obfs"] = px["obfs"]
                out.append({"name": name, "outbound": ob}); continue
            elif t == "tuic":
                ob = {"type": "tuic", "tag": "proxy", "server": host, "server_port": port, "uuid": px["uuid"],
                      "password": px.get("password", ""), "congestion_control": px.get("congestion-controller", "bbr"),
                      "udp_relay_mode": px.get("udp-relay-mode", "native"), "tls": _clash_tls(px, host)}
                out.append({"name": name, "outbound": ob}); continue
            elif t == "anytls":
                ob = {"type": "anytls", "tag": "proxy", "server": host, "server_port": port,
                      "password": str(px["password"]), "tls": _clash_tls(px, host)}
                out.append({"name": name, "outbound": ob}); continue
            elif t in ("socks5", "http"):
                ob = {"type": "socks" if t == "socks5" else "http", "tag": "proxy", "server": host, "server_port": port}
                if t == "socks5":
                    ob["version"] = "5"
                if px.get("username"):
                    ob["username"], ob["password"] = px["username"], str(px.get("password", ""))
                if px.get("tls"):
                    ob["tls"] = _clash_tls(px, host)
                out.append({"name": name, "outbound": ob}); continue
            elif t == "wireguard":
                addrs = [a for a in (px.get("ip"), px.get("ipv6")) if a]
                addrs = [a if "/" in a else a + ("/128" if ":" in a else "/32") for a in addrs] or ["10.0.0.2/32"]
                peer = {"address": host, "port": port, "public_key": px["public-key"], "allowed_ips": ["0.0.0.0/0", "::/0"]}
                if px.get("pre-shared-key"):
                    peer["pre_shared_key"] = px["pre-shared-key"]
                rs = px.get("reserved")
                if isinstance(rs, list):
                    peer["reserved"] = [int(x) for x in rs]
                out.append({"name": name, "outbound": {"type": "wireguard", "tag": "proxy", "address": addrs,
                            "private_key": px["private-key"], "mtu": int(px.get("mtu", 1408)), "peers": [peer]}})
                continue
            else:
                continue
            try:
                out.append({"name": name, "outbound": finish(ob, p, host, t == "trojan")})
            except NeedXray:
                continue
        except Exception:
            continue
    return out


def parse_any(text):
    parse_any.skipped = 0
    text = text.strip()
    if text.startswith("{"):
        try:
            doc = json.loads(text)
            res = []
            for o in list(doc.get("outbounds", [])) + [e for e in doc.get("endpoints", []) if e.get("type") == "wireguard"]:
                if o.get("type") in JSON_TYPES or (o.get("type") == "wireguard" and o.get("peers")):
                    o = dict(o)
                    name = o.get("tag", o.get("server", "server"))
                    o["tag"] = "proxy"
                    o.pop("detour", None)
                    res.append({"name": name, "outbound": o})
            return res
        except Exception:
            return []
    if re.search(r"^\s*proxies\s*:", text, re.M):
        try:
            import yaml
            return from_clash(yaml.safe_load(text))
        except Exception:
            return []
    first = text.split("\n")[0] if text else ""
    if "://" not in first:
        try:
            text = b64d(text)
        except Exception:
            pass
    res = []
    for line in text.splitlines():
        r = parse_link(line)
        if r:
            res.append({"name": r[0], "outbound": r[1]})
        elif line.strip().startswith(SCHEMES):
            parse_any.skipped += 1
    return res


COUNTRIES = {
    "NL": ["нидерланд", "netherland", "amsterdam", "голланд"], "DE": ["герман", "germany", "frankfurt", "berlin", "франкфурт"],
    "FR": ["франц", "france", "paris", "париж"], "US": ["сша", "usa", "united states", "america", "new york", "los angeles", "miami"],
    "JP": ["япон", "japan", "tokyo"], "CA": ["канад", "canada", "toronto"], "GB": ["великобритан", "united kingdom", "england", "london", "uk"],
    "RU": ["росси", "russia", "moscow", "москва"], "FI": ["финлянд", "finland", "helsinki"], "SE": ["швеци", "sweden", "stockholm"],
    "PL": ["польш", "poland", "warsaw"], "TR": ["турци", "turkey", "istanbul"], "SG": ["сингапур", "singapore"],
    "HK": ["гонконг", "hong kong"], "KZ": ["казахстан", "kazakhstan"], "UA": ["украин", "ukraine"], "CH": ["швейцар", "switzerland"],
    "AT": ["австри", "austria"], "IT": ["итал", "italy"], "ES": ["испан", "spain"], "LT": ["литв", "lithuania"],
    "LV": ["латв", "latvia"], "EE": ["эстон", "estonia"], "AM": ["армен", "armenia"], "GE": ["грузи", "georgia"],
}


def detect_cc(name):
    flags = [c for c in name if 0x1F1E6 <= ord(c) <= 0x1F1FF]
    if len(flags) >= 2:
        return "".join(chr(ord(c) - 0x1F1E6 + 65) for c in flags[:2])
    n = name.lower()
    for cc, kws in COUNTRIES.items():
        if any(k in n for k in kws) or re.search(r"(?<![a-z])%s(?![a-z])" % cc.lower(), n):
            return cc
    return ""


def clean_name(name):
    return re.sub("[\U0001F1E6-\U0001F1FF]", "", name).strip() or "Server"


def sid_of(name, ob):
    h, p = addr_of(ob)
    key = "|".join(str(x) for x in (ob.get("type"), h, p, ob.get("uuid") or ob.get("password") or ob.get("private_key") or "", name))
    return hashlib.sha1(key.encode()).hexdigest()[:10]


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "v2rayN/6.45"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read().decode("utf-8", "ignore")


# ---------------------------------------------------------------- core config
def domains(text):
    return [d.strip().lower() for d in re.split(r"[\s,;]+", text or "") if d.strip()]


def tune_outbound(ob, S):
    ob = json.loads(json.dumps(ob))
    typ = ob.get("type")
    tls = ob.get("tls")
    if tls and tls.get("enabled"):
        if typ in ("vless", "vmess", "trojan"):
            if S["fp"] != "auto":
                tls["utls"] = {"enabled": True, "fingerprint": S["fp"]}
            elif "utls" not in tls:
                tls["utls"] = {"enabled": True, "fingerprint": "chrome"}
            if S["fragment"] and "reality" not in tls:
                tls["fragment"] = True
    if (S["mux"] and typ in ("vless", "vmess", "trojan", "shadowsocks") and not ob.get("flow")
            and (ob.get("transport") or {}).get("type") != "grpc"):
        ob["multiplex"] = {"enabled": True, "protocol": "h2mux", "max_connections": 4, "padding": True}
    if typ in ("hysteria", "hysteria2"):
        if int(S.get("hy_up") or 0) > 0:
            ob["up_mbps"] = int(S["hy_up"])
        if int(S.get("hy_down") or 0) > 0:
            ob["down_mbps"] = int(S["hy_down"])
    if ob.get("server_ports"):
        ob.pop("server_port", None)
    if typ == "hysteria":
        ob.setdefault("up_mbps", 100)
        ob.setdefault("down_mbps", 100)
    return ob


def build_config(ob, S, mode, api_port=API_PORT, xray_port=None):
    ob = tune_outbound(ob, S)
    typ = ob.get("type")
    first_rules = []
    find_process = False
    if typ == "xray":
        ob = {"type": "socks", "tag": "proxy", "server": "127.0.0.1", "server_port": xray_port, "version": "5"}
        first_rules.append({"process_name": ["xray.exe"], "outbound": "direct"})
        find_process = True
    ob["tag"] = "proxy"
    if mode == "tun":
        addr = ["172.19.0.1/30"] + (["fdfe:dcba:9876::1/126"] if S["ipv6"] else [])
        stack = S.get("tun_stack", "mixed")
        inbound = {"type": "tun", "tag": "tun-in", "address": addr, "auto_route": bool(S["auto_route"]),
                   "strict_route": bool(S["strict_route"]),
                   "stack": stack if stack in ("mixed", "system", "gvisor") else "mixed"}
        if int(S.get("tun_mtu") or 0) > 0:
            inbound["mtu"] = int(S["tun_mtu"])
    else:
        inbound = {"type": "mixed", "tag": "in", "listen": "127.0.0.1", "listen_port": int(S["port"])}
    rules = first_rules + [{"action": "sniff"}, {"protocol": "dns", "action": "hijack-dns"}]
    if S["block_quic"]:
        rules.append({"protocol": "quic", "action": "reject"})
    rules.append({"ip_is_private": True, "outbound": "direct"})
    if domains(S["custom_proxy"]):
        rules.append({"domain_suffix": domains(S["custom_proxy"]), "outbound": "proxy"})
    if domains(S["custom_direct"]):
        rules.append({"domain_suffix": domains(S["custom_direct"]), "outbound": "direct"})
    if S["routing"] == "bypass_ru":
        rules.append({"domain_suffix": ["ru", "su", "xn--p1ai"], "outbound": "direct"})
    route = {"auto_detect_interface": True, "final": "proxy", "rules": rules,
             "default_domain_resolver": {"server": "local"}}
    if find_process:
        route["find_process"] = True
    cfg = {
        "log": {"level": "warn", "timestamp": True},
        "dns": {"servers": [{"type": "https", "tag": "remote", "server": S["dns"], "detour": "proxy"},
                            {"type": "local", "tag": "local"}],
                "final": "remote", "strategy": "prefer_ipv4" if S["ipv6"] else "ipv4_only"},
        "inbounds": [inbound],
        "outbounds": [{"type": "direct", "tag": "direct"}] if typ == "wireguard" else [ob, {"type": "direct", "tag": "direct"}],
        "route": route,
        "experimental": {"clash_api": {"external_controller": f"127.0.0.1:{api_port}"}},
    }
    if typ == "wireguard":
        cfg["endpoints"] = [ob]
    return cfg


# ---------------------------------------------------------------- windows helpers
NOPROXY = urllib.request.build_opener(urllib.request.ProxyHandler({}))
_MUTEX = None


def _boost(proc):
    """Opt the child process out of Windows power throttling (EcoQoS) - hidden background processes get throttled."""
    if os.name != "nt":
        return
    try:
        class PTS(ctypes.Structure):
            _fields_ = [("v", ctypes.c_ulong), ("c", ctypes.c_ulong), ("s", ctypes.c_ulong)]
        st = PTS(1, 1, 0)
        ctypes.windll.kernel32.SetProcessInformation(ctypes.c_void_p(int(proc._handle)), 4, ctypes.byref(st), ctypes.sizeof(st))
    except Exception:
        pass


def _boost_self():
    if os.name != "nt":
        return
    try:
        class PTS(ctypes.Structure):
            _fields_ = [("v", ctypes.c_ulong), ("c", ctypes.c_ulong), ("s", ctypes.c_ulong)]
        st = PTS(1, 1, 0)
        ctypes.windll.kernel32.SetProcessInformation(ctypes.c_void_p(-1), 4, ctypes.byref(st), ctypes.sizeof(st))
    except Exception:
        pass


def _spawn(cmd):
    p = subprocess.Popen(cmd, cwd=BASE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                         encoding="utf-8", errors="ignore",
                         creationflags=NOWIN | (0x8000 if os.name == "nt" else 0))
    _boost(p)
    return p


EN_PY = {
    "Не найден sing-box.exe (ядро). Пересоберите проект.": "sing-box.exe (core) not found. Rebuild the project.",
    "Нет серверов. Добавьте подписку.": "No servers. Add a subscription.",
    "Не удалось запустить ядро: {e}": "Failed to start the core: {e}",
    "Ядро завершилось с ошибкой": "The core exited with an error",
    "(код {c})": "(code {c})",
    "Ядро остановилось (код {c}). Переподключаюсь…": "The core stopped (code {c}). Reconnecting…",
    "Сервер не отвечает. Переключаюсь на «{n}»": "Server is not responding. Switching to “{n}”",
    "Ядро постоянно падает (код {c}).": "The core keeps crashing (code {c}).",
    "Введите ссылку подписки (http/https)": "Enter a subscription link (http/https)",
    "Не удалось загрузить: {e}": "Download failed: {e}",
    "В подписке не найдено серверов": "No servers found in the subscription",
    " (пропущено {n}: протокол не поддерживается ядром)": " ({n} skipped: protocol not supported)",
    "Не удалось распознать серверы в файле": "Could not recognize any servers in the file",
    "Для файла обновление недоступно": "Refresh is not available for files",
    "Не найден sing-box.exe": "sing-box.exe not found",
    "Не удалось запустить проверку: ": "Could not start the check: ",
    "Для этого сервера нужен xray.exe (XHTTP/KCP). Пересоберите проект.": "This server needs xray.exe (XHTTP/KCP). Rebuild the project.",
    "Xray не запустился": "Xray failed to start",
    "Открыть CatNet": "Open CatNet", "Подключить": "Connect", "Отключить": "Disconnect", "Выход": "Exit",
    "Подключено": "Connected", "Отключено": "Disconnected",
    "CatNet продолжает работать в фоне": "CatNet keeps running in the background",
    "Тест скорости не удался": "Speed test failed",
}


def free_port():
    with socket.socket() as sk:
        sk.bind(("127.0.0.1", 0))
        return sk.getsockname()[1]


def single_instance():
    """Only one CatNet at a time (two copies would fight over TUN and ports)."""
    global _MUTEX
    if os.name != "nt":
        return True
    try:
        k = ctypes.WinDLL("kernel32", use_last_error=True)
        k.CreateMutexW.restype = ctypes.c_void_p
        _MUTEX = k.CreateMutexW(None, False, "CatNetSingleInstanceMutex")
        if ctypes.get_last_error() == 183:
            u = ctypes.windll.user32
            h = u.FindWindowW(None, "CatNet")
            if h:
                u.ShowWindow(ctypes.c_void_p(h), 9)
                u.SetForegroundWindow(ctypes.c_void_p(h))
            return False
    except Exception:
        pass
    return True


def is_admin():
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def set_sys_proxy(enable, port=2080):
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                           0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
        if enable:
            winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, f"127.0.0.1:{port}")
            winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, "<local>")
        winreg.CloseKey(k)
        ctypes.windll.wininet.InternetSetOptionW(0, 39, 0, 0)
        ctypes.windll.wininet.InternetSetOptionW(0, 37, 0, 0)
    except Exception:
        pass


def set_autostart(on, minimized=True):
    if not FROZEN or os.name != "nt":
        return
    try:
        if on:
            subprocess.run(["schtasks", "/Create", "/TN", "CatNet", "/TR", f'"{sys.executable}"' + (" --minimized" if minimized else ""), "/SC", "ONLOGON",
                            "/RL", "HIGHEST", "/F"], creationflags=NOWIN, capture_output=True)
        else:
            subprocess.run(["schtasks", "/Delete", "/TN", "CatNet", "/F"], creationflags=NOWIN, capture_output=True)
    except Exception:
        pass


def tcp_ping(host, port):
    try:
        t = time.time()
        with socket.create_connection((host, int(port)), timeout=2.5):
            return max(1, int((time.time() - t) * 1000))
    except Exception:
        return None


def tls_ping(host, port):
    try:
        import ssl
        ctx = ssl._create_unverified_context()
        sni = None if re.fullmatch(r"[\d.:]+", host or "") else host
        t = time.time()
        with socket.create_connection((host, int(port)), timeout=3) as sk:
            with ctx.wrap_socket(sk, server_hostname=sni):
                return max(1, int((time.time() - t) * 1000))
    except Exception:
        return None


def icmp_ping(host):
    if os.name != "nt":
        return None
    try:
        r = subprocess.run(["ping", "-n", "1", "-w", "2000", host], capture_output=True,
                           creationflags=NOWIN, timeout=6)
        out = r.stdout.decode("cp866", "ignore")
        if "TTL=" not in out.upper():
            return None
        m = re.search(r"(\d+)\D*$", out.strip().splitlines()[-1])
        return max(1, int(m.group(1))) if m else 1
    except Exception:
        return None


def pc_info(lang="ru"):
    import getpass, platform
    info = {"user": getpass.getuser(), "domain": os.environ.get("USERDOMAIN", ""),
            "computer": platform.node(), "arch": platform.machine(), "cores": os.cpu_count() or 0,
            "admin": is_admin(), "os": platform.platform(), "cpu": platform.processor(), "ram": "", "ip": "", "uptime": ""}
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows NT\CurrentVersion")
        name = winreg.QueryValueEx(k, "ProductName")[0]
        build = int(winreg.QueryValueEx(k, "CurrentBuild")[0])
        try: ver = winreg.QueryValueEx(k, "DisplayVersion")[0]
        except Exception: ver = ""
        if build >= 22000:
            name = name.replace("Windows 10", "Windows 11")
        info["os"] = (f"{name} {ver} (build {build})" if lang == "en" else f"{name} {ver} (сборка {build})").replace("  ", " ")
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
        info["cpu"] = winreg.QueryValueEx(k, "ProcessorNameString")[0].strip()
    except Exception:
        pass
    try:
        class MS(ctypes.Structure):
            _fields_ = [("l", ctypes.c_ulong), ("load", ctypes.c_ulong), ("total", ctypes.c_ulonglong),
                        ("avail", ctypes.c_ulonglong), ("tp", ctypes.c_ulonglong), ("ap", ctypes.c_ulonglong),
                        ("tv", ctypes.c_ulonglong), ("av", ctypes.c_ulonglong), ("ax", ctypes.c_ulonglong)]
        m = MS(); m.l = ctypes.sizeof(MS)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
        info["ram"] = f"{m.total / 2**30:.1f} GB (used {m.load}%)" if lang == "en" else f"{m.total / 2**30:.1f} ГБ (занято {m.load}%)"
        ms = ctypes.windll.kernel32.GetTickCount64() if hasattr(ctypes.windll.kernel32, "GetTickCount64") else 0
        sec = int(ms / 1000)
        info["uptime"] = (f"{sec // 86400} d {sec % 86400 // 3600} h {sec % 3600 // 60} min" if lang == "en" else f"{sec // 86400} д {sec % 86400 // 3600} ч {sec % 3600 // 60} мин")
    except Exception:
        pass
    try:
        u = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        u.connect(("10.255.255.255", 1)); info["ip"] = u.getsockname()[0]; u.close()
    except Exception:
        pass
    return info


class _RECT(ctypes.Structure):
    _fields_ = [("l", ctypes.c_long), ("t", ctypes.c_long), ("r", ctypes.c_long), ("b", ctypes.c_long)]


def _job_attach(proc):
    """Kill sing-box automatically if CatNet dies (no orphan TUN adapters)."""
    try:
        from ctypes import wintypes as wt
        class BASIC(ctypes.Structure):
            _fields_ = [("a", ctypes.c_int64), ("b", ctypes.c_int64), ("flags", wt.DWORD), ("c", ctypes.c_size_t),
                        ("d", ctypes.c_size_t), ("e", wt.DWORD), ("f", ctypes.c_size_t), ("g", wt.DWORD), ("h", wt.DWORD)]
        class IOC(ctypes.Structure):
            _fields_ = [(n, ctypes.c_ulonglong) for n in "abcdef"]
        class EXT(ctypes.Structure):
            _fields_ = [("basic", BASIC), ("io", IOC), ("a", ctypes.c_size_t), ("b", ctypes.c_size_t),
                        ("c", ctypes.c_size_t), ("d", ctypes.c_size_t)]
        k = ctypes.windll.kernel32
        k.CreateJobObjectW.restype = wt.HANDLE
        k.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
        k.SetInformationJobObject.argtypes = [wt.HANDLE, ctypes.c_int, ctypes.c_void_p, wt.DWORD]
        job = k.CreateJobObjectW(None, None)
        info = EXT(); info.basic.flags = 0x2000
        k.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info))
        k.AssignProcessToJobObject(job, int(proc._handle))
        return job
    except Exception:
        return None


# ---------------------------------------------------------------- API exposed to the UI
class Api:
    def __init__(self):
        os.makedirs(APPDIR, exist_ok=True)
        self._window = None
        self._lock = threading.RLock()
        self._proc = None
        self._mode = None
        self._log = collections.deque(maxlen=300)
        self._hist_d = collections.deque([0] * 60, maxlen=60)
        self._hist_u = collections.deque([0] * 60, maxlen=60)
        self._down = self._up = 0
        self._tot = (0, 0)
        self._since = 0
        self._ip = ""
        self._error = ""
        self._ping = {}
        self._cur = ""
        self._api_port = API_PORT
        self._xray = None
        self._icon = None
        self._tray_ok = False
        self._notified = False
        self._quitting = False
        self._notice = ""
        self._reconnecting = False
        self._crashes = []
        self._failed = {}
        self._job = None
        try:
            self._d = json.load(open(DATA_FILE, encoding="utf-8"))
        except Exception:
            self._d = {}
        for k, v in dict(settings={}, subs=[], fav=[], recent=[], selected="",
                         stats={"sessions": 0, "down": 0, "up": 0}, profile={"name": "CatNet User"}).items():
            self._d.setdefault(k, v)
        for k, v in DEFAULTS.items():
            self._d["settings"].setdefault(k, v)
        atexit.register(self._cleanup)

    def _t(self, ru):
        return EN_PY.get(ru, ru) if self._d["settings"].get("lang") == "en" else ru

    # -- storage
    def _save(self):
        with self._lock:
            json.dump(self._d, open(DATA_FILE, "w", encoding="utf-8"), ensure_ascii=False)

    def _servers(self):
        for sub in self._d["subs"]:
            for s in sub["servers"]:
                yield sub, s

    def _find(self, sid):
        for _, s in self._servers():
            if s["id"] == sid:
                return s
        return None

    # -- state
    def get_state(self):
        d = self._d
        servers = [{"id": s["id"], "name": s["name"], "sub": sub["name"], "cc": s["cc"],
                    "ping": self._ping.get(s["id"]), "fav": s["id"] in d["fav"]} for sub, s in self._servers()]
        subs = [{"id": s["id"], "name": s["name"], "url": s["url"], "updated": s["updated"],
                 "count": len(s["servers"])} for s in d["subs"]]
        return {"settings": d["settings"], "subs": subs, "servers": servers, "selected": d["selected"],
                "recent": d["recent"], "stats": d["stats"], "profile": d["profile"], "admin": is_admin(),
                "core": os.path.exists(CORE), "version": VERSION, "frozen": FROZEN}

    # -- subscriptions
    def _make_servers(self, items):
        out, seen = [], set()
        for it in items:
            name = clean_name(it["name"])
            sid = sid_of(name, it["outbound"])
            if sid in seen:
                continue
            seen.add(sid)
            out.append({"id": sid, "name": name, "cc": detect_cc(it["name"]), "outbound": it["outbound"]})
        return out

    def add_subscription(self, url):
        url = (url or "").strip()
        if not url.startswith(("http://", "https://")):
            return {"ok": False, "error": "Введите ссылку подписки (http/https)"}
        try:
            items = parse_any(fetch(url))
            skipped = parse_any.skipped
        except Exception as e:
            return {"ok": False, "error": f"Не удалось загрузить: {e}"}
        if not items:
            return {"ok": False, "error": "В подписке не найдено серверов" + (f" (пропущено {skipped}: протокол не поддерживается ядром)" if skipped else "")}
        with self._lock:
            sub = next((s for s in self._d["subs"] if s["url"] == url), None)
            if not sub:
                sub = {"id": hashlib.sha1(url.encode()).hexdigest()[:8], "name": urlsplit(url).hostname or "Подписка",
                       "url": url, "updated": 0, "servers": []}
                self._d["subs"].append(sub)
            sub["servers"] = self._make_servers(items)
            sub["updated"] = int(time.time())
        self._save()
        return {"ok": True, "count": len(sub["servers"]), "skipped": skipped}

    def import_text(self, name, text):
        items = parse_any(text or "")
        skipped = parse_any.skipped
        if not items:
            return {"ok": False, "error": "Не удалось распознать серверы в файле"}
        sid = hashlib.sha1((name + str(time.time())).encode()).hexdigest()[:8]
        with self._lock:
            self._d["subs"].append({"id": sid, "name": name or "Файл", "url": "", "updated": int(time.time()),
                                    "servers": self._make_servers(items)})
        self._save()
        return {"ok": True, "count": len(items), "skipped": skipped}

    def refresh_subscription(self, sub_id):
        sub = next((s for s in self._d["subs"] if s["id"] == sub_id), None)
        if not sub or not sub["url"]:
            return {"ok": False, "error": "Для файла обновление недоступно"}
        return self.add_subscription(sub["url"])

    def remove_subscription(self, sub_id):
        with self._lock:
            self._d["subs"] = [s for s in self._d["subs"] if s["id"] != sub_id]
        self._save()
        return True

    # -- servers
    def toggle_fav(self, sid):
        fav = self._d["fav"]
        fav.remove(sid) if sid in fav else fav.append(sid)
        self._save()
        return True

    def select_server(self, sid):
        self._d["selected"] = sid
        self._save()
        if self._proc:
            return self.connect()
        return {"ok": True}

    def _ping_one(self, method, ob):
        h, p = addr_of(ob)
        if method == "tls":
            return tls_ping(h, p)
        if method == "icmp":
            return icmp_ping(h)
        return tcp_ping(h, p)

    def ping_all(self):
        S = self._d["settings"]
        method = S["ping_method"]
        items = {}
        for _, sv in self._servers():
            items[sv["id"]] = sv["outbound"]
        res, err = {}, ""
        xray_items = {k: v for k, v in items.items() if v.get("type") == "xray"}
        if method == "http":
            res, err = self._ping_http({k: v for k, v in items.items() if k not in xray_items}, S)
            todo = {k: v for k, v in xray_items.items() if not v.get("_udp")}
            m2 = "tcp"
        else:
            # UDP protocols (hysteria, tuic, wireguard) cannot be probed over TCP: measure them through the proxy instead
            udp = {k: v for k, v in items.items() if is_udp(v) and k not in xray_items}
            todo = {k: v for k, v in items.items() if k not in udp and not (k in xray_items and v.get("_udp"))}
            m2 = method
            if udp:
                r2, _e = self._ping_http(udp, S)
                res.update(r2)
        if todo:
            with concurrent.futures.ThreadPoolExecutor(24) as ex:
                for k, v in zip(todo, ex.map(lambda it: self._ping_one(m2, it), todo.values())):
                    if v is not None:
                        res[k] = v
        self._ping = res
        return {"ok": not err, "error": err, "method": method, "count": len(res)}

    def _ping_http(self, items, S):
        if not os.path.exists(CORE):
            return {}, self._t("Не найден sing-box.exe")
        api_port, mixed_port = free_port(), free_port()
        obs, eps = [], []
        for sid, ob in items.items():
            if ob.get("type") == "xray":
                continue
            o = tune_outbound(ob, S)
            o["tag"] = sid
            (eps if o.get("type") == "wireguard" else obs).append(o)
        tags = [o["tag"] for o in obs + eps]
        if not tags:
            return {}, ""
        cfg = {"log": {"level": "error"}, "dns": {"servers": [{"type": "local", "tag": "local"}]},
               "inbounds": [{"type": "mixed", "tag": "in", "listen": "127.0.0.1", "listen_port": mixed_port}],
               "outbounds": obs + [{"type": "direct", "tag": "direct"}],
               "route": {"auto_detect_interface": True, "default_domain_resolver": {"server": "local"}},
               "experimental": {"clash_api": {"external_controller": f"127.0.0.1:{api_port}"}}}
        if eps:
            cfg["endpoints"] = eps
        json.dump(cfg, open(PING_CFG, "w"))
        logf = open(PING_LOG, "w")
        p = subprocess.Popen([CORE, "run", "-c", PING_CFG], cwd=BASE, stdout=logf, stderr=subprocess.STDOUT,
                             creationflags=NOWIN)
        res = {}
        try:
            ok = False
            for _ in range(40):
                time.sleep(0.15)
                if p.poll() is not None:
                    break
                try:
                    NOPROXY.open(f"http://127.0.0.1:{api_port}/version", timeout=1).read(); ok = True; break
                except Exception:
                    pass
            if not ok:
                logf.flush()
                try: tail = open(PING_LOG, encoding="utf-8", errors="ignore").read()[-300:]
                except Exception: tail = ""
                return {}, self._t("Не удалось запустить проверку: ") + tail
            from urllib.parse import quote
            def one(sid):
                try:
                    u = f"http://127.0.0.1:{api_port}/proxies/{sid}/delay?url={quote(S['ping_url'], safe='')}&timeout=5000"
                    with NOPROXY.open(u, timeout=8) as r:
                        d = json.loads(r.read().decode()).get("delay")
                    return sid, d
                except Exception:
                    return sid, None
            with concurrent.futures.ThreadPoolExecutor(16) as ex:
                res = {k: v for k, v in ex.map(one, tags) if v}
        finally:
            try: p.terminate(); p.wait(3)
            except Exception: pass
            logf.close()
        return res, ""

    def get_pc_info(self):
        return pc_info(self._d["settings"].get("lang", "ru"))

    # -- settings
    def set_setting(self, key, value):
        if key not in DEFAULTS:
            return False
        self._d["settings"][key] = value
        self._save()
        S = self._d["settings"]
        if key in ("autostart", "tray") and S["autostart"]:
            set_autostart(True, bool(S["tray"]))
        elif key == "autostart":
            set_autostart(False)
        if key == "tray":
            self._tray_apply()
        if key == "lang":
            self._tray_title()
        if key in CONFIG_KEYS and self._proc:
            return self.connect()
        return True

    def reset_settings(self):
        self._d["settings"] = dict(DEFAULTS)
        self._save()
        return self._d["settings"]

    def set_profile_name(self, name):
        self._d["profile"]["name"] = (name or "CatNet User")[:40]
        self._save()
        return True

    # -- connection
    def _kill(self, proc):
        if proc is None:
            return
        try:
            if proc.poll() is None:
                proc.terminate()
                try: proc.wait(4)
                except Exception: proc.kill()
        except Exception:
            pass

    def connect(self):
        with self._lock:
            self._stop()
            S = self._d["settings"]
            if not os.path.exists(CORE):
                return {"ok": False, "error": self._t("Не найден sing-box.exe (ядро). Пересоберите проект.")}
            srv = self._find(self._d["selected"])
            if not srv:
                if not any(True for _ in self._servers()):
                    return {"ok": False, "error": self._t("Нет серверов. Добавьте подписку.")}
                if S["best_server"]:
                    self.ping_all()
                    cand = [s for _, s in self._servers() if s["id"] in self._ping]
                    srv = min(cand, key=lambda s: self._ping[s["id"]]) if cand else next(s for _, s in self._servers())
                else:
                    srv = next(s for _, s in self._servers())
                self._d["selected"] = srv["id"]
            mode = S["mode"]
            if mode == "auto":
                mode = "tun" if is_admin() else "proxy"
            self._log.clear()
            logf = None
            try:
                logf = open(CORE_LOG, "w", encoding="utf-8", buffering=1)
                logf.write(f"== {time.strftime('%Y-%m-%d %H:%M:%S')} | {srv['name']} | {mode} ==\n")
            except Exception:
                pass
            ob = srv["outbound"]
            xp, xport = None, None
            if ob.get("type") == "xray":
                if not os.path.exists(XRAY):
                    return {"ok": False, "error": self._t("Для этого сервера нужен xray.exe (XHTTP/KCP). Пересоберите проект.")}
                xport = free_port()
                json.dump(make_xray_config(ob["_xray"], xport), open(XRAY_CFG, "w"))
                try:
                    xp = _spawn([XRAY, "run", "-c", XRAY_CFG])
                except Exception as e:
                    return {"ok": False, "error": self._t("Не удалось запустить ядро: {e}").format(e=e)}
                self._xray = xp
                self._xjob = _job_attach(xp) if os.name == "nt" else None
                threading.Thread(target=self._reader, args=(xp, logf, "[xray] ", False), daemon=True).start()
                up = False
                for _ in range(40):
                    if xp.poll() is not None:
                        break
                    try:
                        socket.create_connection(("127.0.0.1", xport), timeout=0.2).close(); up = True; break
                    except Exception:
                        time.sleep(0.1)
                if not up:
                    time.sleep(0.2)
                    err = "\n".join(list(self._log)[-6:]) or self._t("Xray не запустился")
                    self._kill(xp); self._xray = None
                    return {"ok": False, "error": err}
            self._api_port = free_port()
            cfg = build_config(ob, S, mode, self._api_port, xport)
            json.dump(cfg, open(RUN_CFG, "w"), indent=1)
            try:
                p = _spawn([CORE, "run", "-c", RUN_CFG])
            except Exception as e:
                self._kill(xp); self._xray = None
                return {"ok": False, "error": self._t("Не удалось запустить ядро: {e}").format(e=e)}
            self._proc, self._mode, self._cur = p, mode, srv["id"]
            self._job = _job_attach(p) if os.name == "nt" else None
            threading.Thread(target=self._reader, args=(p, logf), daemon=True).start()
            for _ in range(25):
                time.sleep(0.1)
                if p.poll() is not None:
                    break
            if p.poll() is not None:
                time.sleep(0.2)
                err = "\n".join(list(self._log)[-6:]) or self._t("Ядро завершилось с ошибкой")
                self._proc = self._mode = None
                self._kill(xp); self._xray = None
                return {"ok": False, "error": f"{err}\n" + self._t("(код {c})").format(c=p.returncode)}
            if mode == "proxy":
                set_sys_proxy(True, S["port"])
            self._since = time.time()
            self._down = self._up = 0
            self._tot = (0, 0)
            self._ip = ""
            self._error = ""
            self._reconnecting = False
            for h in (self._hist_d, self._hist_u):
                h.extend([0] * 60)
            rec = [x for x in self._d["recent"] if x != srv["id"]]
            self._d["recent"] = ([srv["id"]] + rec)[:10]
            self._save()
            threading.Thread(target=self._stats, args=(p, self._api_port), daemon=True).start()
            threading.Thread(target=self._get_ip, args=(p, mode, S["port"]), daemon=True).start()
            threading.Thread(target=self._watch, args=(p, xp), daemon=True).start()
            self._tray_title()
            return {"ok": True}

    def _reader(self, p, logf, prefix="", close=True):
        try:
            for line in p.stdout:
                line = prefix + line.rstrip()
                self._log.append(line)
                if logf:
                    logf.write(line + "\n")
        except Exception:
            pass
        finally:
            try:
                if logf and close: logf.close()
            except Exception:
                pass

    def _stats(self, p, port):
        last = None
        while self._proc is p and p.poll() is None:
            try:
                with NOPROXY.open(f"http://127.0.0.1:{port}/connections", timeout=2) as r:
                    j = json.loads(r.read().decode())
                d, u = j.get("downloadTotal", 0), j.get("uploadTotal", 0)
                if last:
                    self._down, self._up = max(0, d - last[0]), max(0, u - last[1])
                last, self._tot = (d, u), (d, u)
            except Exception:
                self._down = self._up = 0
            self._hist_d.append(self._down)
            self._hist_u.append(self._up)
            time.sleep(1)

    def _get_ip(self, p, mode, port):
        time.sleep(2)
        for _ in range(4):
            if self._proc is not p:
                return
            try:
                h = urllib.request.ProxyHandler({"http": f"http://127.0.0.1:{port}", "https": f"http://127.0.0.1:{port}"}
                                                if mode == "proxy" else {})
                self._ip = urllib.request.build_opener(h).open("https://api.ipify.org", timeout=6).read().decode().strip()
                return
            except Exception:
                time.sleep(2)

    # watchdog: restart the core if it dies, fail over to another server if the same one keeps failing
    def _watch(self, p, xp=None):
        while self._proc is p:
            if p.poll() is not None or (xp is not None and xp.poll() is not None):
                self._on_crash(p)
                return
            time.sleep(1)

    def _alt_server(self, cur):
        now = time.time()
        cands = [s for _, s in self._servers() if s["id"] != cur]
        fresh = [s for s in cands if now - self._failed.get(s["id"], 0) > 180]
        pool = fresh or cands
        if not pool:
            return None
        return sorted(pool, key=lambda s: self._ping.get(s["id"], 99999))[0]

    def _on_crash(self, p):
        with self._lock:
            if self._proc is not p:
                return
            code = p.poll()
            if code is None and self._xray is not None:
                code = self._xray.poll()
            tail = "\n".join(list(self._log)[-8:])
            self._proc = None
            self._kill(p)
            self._kill(self._xray); self._xray = None
            if self._mode == "proxy":
                set_sys_proxy(False)
            self._mode = None
            self._reconnecting = True
            d, u = self._tot
            st = self._d["stats"]
            st["sessions"] += 1; st["down"] += d; st["up"] += u
        S = self._d["settings"]
        cur = self._cur
        now = time.time()
        self._failed[cur] = now
        self._crashes = [t for t in self._crashes if now - t < 180] + [now]
        n = len(self._crashes)
        self._notice = self._t("Ядро остановилось (код {c}). Переподключаюсь…").format(c=code)
        if n > 8:
            self._reconnecting = False
            self._error = self._t("Ядро постоянно падает (код {c}).").format(c=code) + "\n" + tail
            return
        time.sleep(1.5)
        r = {}
        for attempt in range(3):
            if not self._reconnecting or self._proc is not None:
                return
            if (n > 2 or attempt > 0) and S.get("failover", True):
                alt = self._alt_server(self._cur)
                if alt:
                    self._d["selected"] = alt["id"]
                    self._notice = self._t("Сервер не отвечает. Переключаюсь на «{n}»").format(n=alt["name"])
            r = self.connect()
            if r.get("ok"):
                return
            self._failed[self._cur] = time.time()
            time.sleep(1)
        self._reconnecting = False
        self._error = r.get("error", tail)

    def _stop(self):
        p = self._proc
        if p:
            self._proc = None
            d, u = self._tot
            st = self._d["stats"]
            st["sessions"] += 1; st["down"] += d; st["up"] += u
            self._kill(p)
        self._kill(self._xray)
        self._xray = None
        if self._mode == "proxy":
            set_sys_proxy(False)
        self._mode = None
        self._down = self._up = 0
        self._ip = ""

    def disconnect(self):
        with self._lock:
            self._reconnecting = False
            self._crashes = []
            self._error = ""
            self._stop()
            self._save()
        self._tray_title()
        return True

    def _cleanup(self):
        try:
            self._reconnecting = False
            self._stop()
        except Exception:
            pass

    def get_status(self):
        p = self._proc
        note, self._notice = self._notice, ""
        return {"connected": bool(p) or self._reconnecting, "reconnecting": self._reconnecting and not p,
                "down": self._down, "up": self._up, "hist": list(self._hist_d), "ip": self._ip,
                "since": self._since if p else 0, "server": self._cur if p else "", "error": self._error,
                "notice": note, "log": list(self._log)[-40:]}

    def get_log(self):
        try:
            txt = open(CORE_LOG, encoding="utf-8", errors="ignore").read()[-12000:]
        except Exception:
            txt = ""
        return txt or "\n".join(self._log)

    def open_logs(self):
        try:
            os.startfile(APPDIR)
        except Exception:
            pass
        return True

    def speed_test(self):
        """Parallel download test through the current connection (TUN: system route, proxy: local port)."""
        S = self._d["settings"]
        h = (urllib.request.ProxyHandler({"http": f"http://127.0.0.1:{S['port']}", "https": f"http://127.0.0.1:{S['port']}"})
             if self._mode == "proxy" else urllib.request.ProxyHandler({}))
        opener = urllib.request.build_opener(h)
        urls = ["https://speed.cloudflare.com/__down?bytes=200000000", "https://cachefly.cachefly.net/100mb.test"]
        total, lock, t0 = [0], threading.Lock(), time.time()
        stop_at = t0 + 8
        def worker(url):
            try:
                with opener.open(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=8) as r:
                    while time.time() < stop_at:
                        b = r.read(65536)
                        if not b:
                            break
                        with lock:
                            total[0] += len(b)
            except Exception:
                pass
        for url in urls:
            ths = [threading.Thread(target=worker, args=(url,), daemon=True) for _ in range(4)]
            [t.start() for t in ths]
            [t.join(10) for t in ths]
            if total[0] > 0:
                break
        dt = max(0.5, time.time() - t0)
        if total[0] == 0:
            return {"ok": False, "error": self._t("Тест скорости не удался")}
        return {"ok": True, "mbs": round(total[0] / dt / 1e6, 2), "connected": bool(self._proc)}

    # -- tray / background
    def _tray_enabled(self):
        return bool(self._d["settings"].get("tray", True)) and self._tray_ok

    def _tray_apply(self):
        want = bool(self._d["settings"].get("tray", True))
        if want and not self._icon:
            try:
                import pystray
                from PIL import Image
                img = Image.open(os.path.join(BASE, "ui", "icon.png")).convert("RGBA").resize((64, 64))
                def toggle(icon, item):
                    threading.Thread(target=lambda: self.disconnect() if self._proc else self.connect(), daemon=True).start()
                menu = pystray.Menu(
                    pystray.MenuItem(lambda i: self._t("Открыть CatNet"), lambda i, it: self.show_window(), default=True),
                    pystray.MenuItem(lambda i: self._t("Отключить") if self._proc else self._t("Подключить"), toggle),
                    pystray.Menu.SEPARATOR,
                    pystray.MenuItem(lambda i: self._t("Выход"), lambda i, it: self.quit()))
                self._icon = pystray.Icon("CatNet", img, "CatNet", menu)
                threading.Thread(target=self._icon.run, daemon=True).start()
                self._tray_ok = True
            except Exception:
                self._icon, self._tray_ok = None, False
        elif not want and self._icon:
            try: self._icon.stop()
            except Exception: pass
            self._icon, self._tray_ok = None, False
        self._tray_title()

    def _tray_title(self):
        try:
            if self._icon:
                self._icon.title = "CatNet - " + (self._t("Подключено") if self._proc else self._t("Отключено"))
                self._icon.update_menu()
        except Exception:
            pass

    def show_window(self):
        try:
            self._window.show()
        except Exception:
            pass
        try:
            u, h = ctypes.windll.user32, self._hwnd()
            u.ShowWindow(ctypes.c_void_p(h), 9)
            u.SetForegroundWindow(ctypes.c_void_p(h))
        except Exception:
            pass

    def quit(self):
        self._quitting = True
        self._cleanup()
        try:
            if self._icon: self._icon.stop()
        except Exception:
            pass
        try:
            self._window.destroy()
        except Exception:
            os._exit(0)

    def close(self):
        """X button: keep the VPN running in the tray (default) or exit completely."""
        if self._tray_enabled():
            try:
                self._window.hide()
                if not self._notified and self._icon:
                    self._notified = True
                    try: self._icon.notify(self._t("CatNet продолжает работать в фоне"), "CatNet")
                    except Exception: pass
                return "hidden"
            except Exception:
                pass
        self.quit()
        return "quit"

    def _autoconnect(self):
        time.sleep(2.0)
        if self._d["settings"].get("autoconnect") and not self._proc and any(True for _ in self._servers()):
            self.connect()

    # -- window (native Win32, physical pixels)
    def _hwnd(self):
        if not getattr(self, "_h", None):
            try:
                self._h = ctypes.windll.user32.FindWindowW(None, "CatNet")
            except Exception:
                self._h = 0
        return self._h

    def get_geometry(self):
        r = _RECT()
        ctypes.windll.user32.GetWindowRect(ctypes.c_void_p(self._hwnd()), ctypes.byref(r))
        return [r.l, r.t, r.r - r.l, r.b - r.t]

    def set_geometry(self, x, y, w, h, mode="size"):
        flags = 0x0004 | 0x0010 | (0x0001 if mode == "move" else 0)
        ctypes.windll.user32.SetWindowPos(ctypes.c_void_p(self._hwnd()), None, int(x), int(y), int(w), int(h), flags)
        return True

    def minimize(self):
        try:
            self._window.minimize()
        except Exception:
            ctypes.windll.user32.ShowWindow(ctypes.c_void_p(self._hwnd()), 6)

    def toggle_maximize(self):
        from ctypes import wintypes as wt
        if getattr(self, "_restore", None):
            x, y, w, h = self._restore
            self._restore = None
            self.set_geometry(x, y, w, h)
            return False
        self._restore = self.get_geometry()
        class MI(ctypes.Structure):
            _fields_ = [("size", wt.DWORD), ("mon", _RECT), ("work", _RECT), ("flags", wt.DWORD)]
        u = ctypes.windll.user32
        u.MonitorFromWindow.restype = ctypes.c_void_p
        mon = u.MonitorFromWindow(ctypes.c_void_p(self._hwnd()), 2)
        mi = MI(); mi.size = ctypes.sizeof(MI)
        u.GetMonitorInfoW(ctypes.c_void_p(mon), ctypes.byref(mi))
        wk = mi.work
        self.set_geometry(wk.l, wk.t, wk.r - wk.l, wk.b - wk.t)
        return True


def set_window_icon(hwnd):
    try:
        ico = os.path.join(BASE, "icon.ico")
        u = ctypes.windll.user32
        u.LoadImageW.restype = ctypes.c_void_p
        for size, kind in ((32, 1), (16, 0)):
            h = u.LoadImageW(None, ico, 1, size, size, 0x10)
            u.SendMessageW(ctypes.c_void_p(hwnd), 0x80, kind, ctypes.c_void_p(h))
    except Exception:
        pass


def reset_stale_proxy(port):
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Internet Settings")
        en = winreg.QueryValueEx(k, "ProxyEnable")[0]
        srv = winreg.QueryValueEx(k, "ProxyServer")[0]
        if en and srv == f"127.0.0.1:{port}":
            set_sys_proxy(False)
    except Exception:
        pass


def main():
    import webview
    if not single_instance():
        return
    api = Api()
    s = api._d["settings"]
    reset_stale_proxy(s["port"])
    _boost_self()
    api._tray_apply()
    hidden = "--minimized" in sys.argv and api._tray_ok
    dark = s["theme"] == "dark"
    win = webview.create_window("CatNet", os.path.join(BASE, "ui", "index.html"), js_api=api,
                                width=1080, height=700, min_size=(720, 520), frameless=True, hidden=hidden,
                                background_color="#2B2B2D" if dark else "#F5F3EF")
    api._window = win
    win.events.shown += lambda: set_window_icon(api._hwnd())
    threading.Thread(target=api._autoconnect, daemon=True).start()
    webview.start()
    try:
        if api._icon: api._icon.stop()
    except Exception:
        pass
    api._cleanup()


if __name__ == "__main__":
    main()
